﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            //string saida = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º","Entrada de Dados");  //interaction para usar a biblioteca do visual basic

                if (auxiliar == "")
                {
                    break;
                }
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;//retorne uma casa
                }
                /*else
                {
                    saida = auxiliar + "\n" + saida;
                }*/
            }

            Array.Reverse(vetor); //inverter
            auxiliar = "";
            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            ArrayList alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            alunos.Remove("Otávio");
            foreach(string s in alunos)
            {
                auxiliar += s + "\n";                
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            string[,] notas = new string[20, 3];
            double media;
            

            for (int linha = 0; linha < 20; linha++) //linha == aluno
                for(int coluna = 0; coluna < 3; coluna++) //coluna == nota
                {
                   notas[linha,coluna] = Interaction.InputBox($"Digite a nota do aluno:");//tentar colocar o número do aluno
                    media = int.Parse(notas[linha,0]) + int.Parse(notas[linha,1]) + int.Parse(notas[linha,2]);
                    media = media / 3;
                    MessageBox.Show($"Aluno" + linha.ToString() + ": " + media + "\n");
                }
                
                
            
            
            
        }
    }
}
