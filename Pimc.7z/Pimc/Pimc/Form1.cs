﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {

        double peso, altura, imc;

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura) || (altura <=0)) 
            {
                MessageBox.Show("Altura inválida!");
                //mskbxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
         
            txtImc.Text = imc.ToString();
            if(imc < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if(imc >= 18.5 &&  imc < 25)
            {
                MessageBox.Show("Dentro da faixa de peso ideal");
            }
            else if(imc >= 25 && imc < 30)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if(imc >=30 && imc < 40)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade grave!");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtImc.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso) || (peso <= 0) )
            {
                MessageBox.Show("Peso inválido!");
                //mskbxPeso.Focus();
            }
        }
    }
}
